var app = angular.module('app',['ngRoute','ngResource']);
app.config(function($routeProvider){
	$routeProvider
		.when('/home',{
			templateUrl : '/itfportal/views/home.html'
		})
		.when('/testcaseCreation',{
			templateUrl : '/itfportal/views/testcaseCreation.html'
		})
		.when('/testdataCreation',{
			templateUrl : '/itfportal/views/testdataCreation.html'
		})
		.when('/testcaseExecution',{
			templateUrl : '/itfportal/views/testcaseExecution.html'
		})
		.otherwise({
			redirectTo:'/home'
		});
});