/**
 * 
 */
package com.ustglobal.itfportal.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author U42998
 *
 */
@Controller
public class HomeController {
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String homeRouting() {
		return "index.html";
	}

}
