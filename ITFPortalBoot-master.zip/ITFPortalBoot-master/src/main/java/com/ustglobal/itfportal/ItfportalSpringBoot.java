package com.ustglobal.itfportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author U42998
 *
 */
@SpringBootApplication
public class ItfportalSpringBoot {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(ItfportalSpringBoot.class, args);
	}

}
