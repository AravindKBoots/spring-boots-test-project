/**
 * 
 */
package com.ustglobal.itfportal.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author U42998
 *
 */
@RestController
public class TestCaseController {
	
	@GetMapping("/interfaces")
	public List<String> getAllInterfaces() {
		List<String> interfaceList = new ArrayList<String>();
		
		return interfaceList; 
	}
	
	@PostMapping("/testcases/create")
	public Boolean createTestcase() {
		return true;
	}

}
