/**
 * 
 */
package com.ustglobal.itfportal.services.impl;

import org.springframework.stereotype.Service;

import com.ustglobal.itfportal.services.InterfaceService;

/**
 * @author aravindk
 *
 */
@Service
public class InterfaceServiceImpl implements InterfaceService {

}
