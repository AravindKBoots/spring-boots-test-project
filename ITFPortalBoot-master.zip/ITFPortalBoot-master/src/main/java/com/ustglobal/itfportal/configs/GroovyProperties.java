/**
 * 
 */
package com.ustglobal.itfportal.configs;

import org.springframework.context.annotation.Configuration;

/**
 * @author aravindk
 *
 */
@Configuration
public class GroovyProperties {

}
