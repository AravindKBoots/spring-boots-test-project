/**
 * 
 */
package com.ustglobal.itfportal.services;

/**
 * @author aravindk
 *
 */
public interface TestSuiteService {

}
