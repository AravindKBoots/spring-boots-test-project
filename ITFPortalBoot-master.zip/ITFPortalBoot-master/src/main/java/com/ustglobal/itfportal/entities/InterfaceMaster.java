/**
 * 
 */
package com.ustglobal.itfportal.entities;

import javax.persistence.Entity;

/**
 * @author aravindk
 *
 */
//@Entity
public class InterfaceMaster {

}
