/**
 * 
 */
package com.ustglobal.itfportal.repositories;

/**
 * @author aravindk
 *
 */
public class InterfaceMasterRepository {

}
