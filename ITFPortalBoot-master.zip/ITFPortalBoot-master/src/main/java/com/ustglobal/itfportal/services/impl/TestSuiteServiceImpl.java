/**
 * 
 */
package com.ustglobal.itfportal.services.impl;

import org.springframework.stereotype.Service;

import com.ustglobal.itfportal.services.TestSuiteService;

/**
 * @author aravindk
 *
 */

@Service
public class TestSuiteServiceImpl implements TestSuiteService{

}
