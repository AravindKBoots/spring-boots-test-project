/**
 * 
 */
package com.ustglobal.itfportal.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author aravindk
 *
 */
@RestController
public class TestDataController {

	
	@GetMapping("/interfaces/testcases")
	public List<String> getAllInterfacesWithTestcase(){
		List<String> interfaceList = new ArrayList<String>();
		
		return interfaceList;
	}
	
	@GetMapping("/testcases/{interfaceName}")
	public List<String> getAllTestcaseByInterface(@PathVariable String interfaceName){
		List<String> testCaseList = new ArrayList<String>();
		
		return testCaseList;
	}
	
	@PutMapping("/testcases/save")
	public Boolean saveTestData() {
		return true;
	}
}
