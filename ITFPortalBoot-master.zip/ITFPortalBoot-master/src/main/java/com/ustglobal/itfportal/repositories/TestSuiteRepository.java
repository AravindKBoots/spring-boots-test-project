/**
 * 
 */
package com.ustglobal.itfportal.repositories;

import org.springframework.stereotype.Repository;

/**
 * @author aravindk
 *
 */
@Repository
public class TestSuiteRepository {

}
