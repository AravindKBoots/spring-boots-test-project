/**
 * 
 */
package com.ustglobal.itfportal.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author U42998
 *
 */
@RestController
public class TestExecutionController {
	
	@GetMapping("/files")
	public void downloadFile() {
		
	}
	
	@PostMapping("/testcases/execute")
	public Boolean executeTestCase() {
		return true;
	}
	
	
	

}
