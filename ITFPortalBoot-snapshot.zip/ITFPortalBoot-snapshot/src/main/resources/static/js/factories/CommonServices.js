/**
 * common services for the ajax calls
 */
app.service('CommonServices', [ '$http', function($http) {
	return {
		getHttpService : function(url) {
			return $http.get(url).then(function(response) {
				// return data when promise resolved
				// that would help you to continue promise chain.
				return response.data;
			});
		},
		postHttpService : function(url, data) {
			return $http.post(url, data).then(function(response) {
				return response.data;
			})
		},
		fileUploadService : function(inputFile, outputFile, data, uploadUrl) {
			var fd = new FormData();
			fd.append('input', inputFile);
			fd.append('output', outputFile);
			var blob = new Blob([ data ], {
				type : "application/json"
			})
			fd.append('testData', blob);
			$http.post(uploadUrl, fd, {
				transformRequest : angular.identity,
				headers : {
					'Content-Type' : undefined
				}
			}).then(function(response) {
				return response.data;
			})
		}
	};
} ]);