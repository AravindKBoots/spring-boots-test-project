app.controller(
			'testDataCreationController',
			[
					'$scope',
					'$http',
					'CommonServices',
					function($scope, $http, CommonServices) {

						$scope.newValue = function(testDataChoice) {
							if (testDataChoice == 'Modify') {
								CommonServices
										.getHttpService(
												"http://localhost:2080/itfportal/testcases/all")
										.then(function(data) {
											$scope.testCaseData = data;
										});

							} else if (testDataChoice == 'Add') {
								CommonServices
										.getHttpService(
												"http://localhost:2080/itfportal/testcases/testdata")
										.then(function(data) {
											$scope.testCaseData = data;
										});
							}
						}

						$scope.checkTestCase = function() {
							if ($scope.testDataChoice !== null
									|| $scope.tesDataChoice !== 'undefined') {
								$scope.newValue($scope.testDataChoice);
							} else {
								alert("select a choice");
							}
						}
						CommonServices
								.getHttpService(
										"http://localhost:2080/itfportal/testsuites")
								.then(function(data) {
									$scope.testSuits = data;
								});

						$scope.save = function() {
							var inputFile = $scope.inputFile;
							var outputFile = $scope.outputFile;
							var data = $scope.selectTestCase;
							if ($scope.testDataChoice == 'Add') {
								var dataJson = JSON.parse(data);
								dataJson["testSuite"] = JSON
										.parse($scope.SelectTesSuite);
								data = JSON.stringify(dataJson);
							}
							var uploadUrl = "http://localhost:2080/itfportal/testcases";
							CommonServices.fileUploadService(inputFile,
									outputFile, data, uploadUrl).then(function(data) {
										$scope.reponse = data;
										var message = 'Test Data uploaded';
										Flash.create('success', message);
									});
						};

					} ]);