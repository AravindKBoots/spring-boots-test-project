app.controller("homeController", function($scope) {
        $scope.message = "This is to Add a new Event";
    });