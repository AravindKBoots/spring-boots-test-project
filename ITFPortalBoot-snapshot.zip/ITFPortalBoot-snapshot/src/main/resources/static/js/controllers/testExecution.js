/**
 * 
 */
app.controller('testExecution', [
		'$scope',
		'$http',
		'CommonServices',
		function($scope, $http, CommonServices) {

			$scope.showDownload=false;
			$scope.downloadUrl='http://localhost:2080/itfportal';
			CommonServices.getHttpService(
					"http://localhost:2080/itfportal/testsuites").then(
					function(data) {
						$scope.testSuits = data;
					});
			$scope.validateTestExecutionForm=function(){
				$scope.Formdata={
						"testSuite":JSON.parse($scope.SelectTestSuite)
				}
				var myJSON = JSON.stringify($scope.Formdata);
				CommonServices.postHttpService(
						'http://localhost:2080/itfportal/testcases/execute',
						myJSON).then(function(data) {
					$scope.response = data;
					console.log(data);
					$scope.showDownload=true;
					var tsId = JSON.parse($scope.SelectTestSuite).tsId;
					$scope.downloadUrl='http://localhost:2080/itfportal/files/'+tsId;
				});
			}

		} ]);