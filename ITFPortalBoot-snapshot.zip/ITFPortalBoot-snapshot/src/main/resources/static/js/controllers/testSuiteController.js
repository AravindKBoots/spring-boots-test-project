app.controller('testSuiteController', [
		'$scope',
		'$http',
		'CommonServices',
		function($scope, $http, CommonServices) {

			$scope.getVal = function() {
				$scope.SelectQueue = $scope.SelectQueue;
			}
			$scope.validateTestCaseForm = function() {
				$scope.Formdata = {
					"tsPlatform" : $scope.testPlatfrm,
					"tsName" : $scope.testSuiteName,
					"inQ" : $scope.InputQueue,
					"outQ" : $scope.OutputQueue,
					"interfaceMaster" : JSON.parse($scope.SelectInterface)

				}
				var myJSON = JSON.stringify($scope.Formdata);
				CommonServices.postHttpService(
						'http://localhost:2080/itfportal/testsuites', myJSON)
						.then(function(data) {
							$scope.reponse = data;
							var message = 'Test suite created';
							Flash.create('success', message);
						});
			}

			CommonServices.getHttpService(
					"http://localhost:2080/itfportal/interfaces").then(
					function(data) {
						$scope.testInterfaces = data;
					});

		} ]);