var app = angular.module('app',['ngRoute','ngResource']);
app.config(function($routeProvider,$locationProvider){
	
	$routeProvider
		.when('/home',{
			templateUrl : '/itfportal/views/home.html',
			controller: 'homeController'
		})
		.when('/testSuiteCreation',{
			templateUrl : '/itfportal/views/testSuiteCreation.html',
			controller: 'testSuiteController'
		})
		.when('/testDataCreation',{
			templateUrl : '/itfportal/views/testDataCreation.html',
			controller:'testDataCreationController'
		})
		.when('/testSuiteExecution',{
			templateUrl : '/itfportal/views/testSuiteExecution.html',
			controller:'testExecution'
		})
		.otherwise({
			redirectTo:'/home'
		});
	$locationProvider.html5Mode(true);
});
app.run(function(){
	var ifHambergerShown = false;	
  var trigger = $('.hamburger'),
      overlay = $('.overlay'),
      menuItem=$('.menuItem'),
     isClosed = false;

    trigger.click(function () {
      hamburger_cross();      
    });
    menuItem.click(function(){
    	hamburger_cross();
    	$('#wrapper').toggleClass('toggled');
    });

    function hamburger_cross() {

      if (isClosed == true) {          
        overlay.hide();
        trigger.removeClass('is-open');
        trigger.addClass('is-closed');
        isClosed = false;
      } else {   
        overlay.show();
        trigger.removeClass('is-closed');
        trigger.addClass('is-open');
        isClosed = true;
      }
  }
  
  $('[data-toggle="offcanvas"]').click(function () {
        $('#wrapper').toggleClass('toggled');
  });  

})
