/**
 * 
 */
package com.ustglobal.itfportal.services;

import java.nio.file.Path;

import com.ustglobal.itfportal.entities.TestExecution;

/**
 * @author U42998
 *
 */
public interface TestExecutionService {
	
	public Boolean saveTestSuiteExecution(TestExecution testExecution) throws Exception;
	public Path downloadTestResult(Long id) throws Exception;

}
