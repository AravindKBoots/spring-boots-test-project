/**
 * 
 */
package com.ustglobal.itfportal.services.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ustglobal.itfportal.configs.GroovyProperties;
import com.ustglobal.itfportal.constants.ITFConstants;
import com.ustglobal.itfportal.entities.TestData;
import com.ustglobal.itfportal.repositories.TestDataRepository;
import com.ustglobal.itfportal.services.TestDataService;

/**
 * @author U42998
 *
 */
@Service
@EnableConfigurationProperties(GroovyProperties.class)
public class TestDataServiceImpl implements TestDataService {
	
	@Autowired
	TestDataRepository testDataRepo;
	
	@Autowired
	GroovyProperties gp;

	/* (non-Javadoc)
	 * @see com.ustglobal.itfportal.services.TestDataService#createTestData(com.ustglobal.itfportal.entities.TestData)
	 */
	@Override
	public Boolean createTestData(TestData testData, MultipartFile input, MultipartFile output) throws Exception {
		
		String destPath = gp.getTestCaseCreationPath()+testData.getTestSuite().getTsName();
		if(Files.exists(Paths.get(destPath))) {
			Path dest_path = Paths.get(destPath).resolve(testData.getTcName()+File.separator);
			Path dest_input_file = dest_path.resolve(input.getOriginalFilename());
			Path dest_output_file = dest_path.resolve(output.getOriginalFilename());
			
			if(!Files.exists(dest_path)) {
				Files.createDirectories(dest_path);
			}
	
			Files.deleteIfExists(dest_input_file);
			Files.createFile(dest_input_file);
			Files.deleteIfExists(dest_output_file);
			Files.createFile(dest_output_file);
			
			/*if(!Files.exists(dest_input_file)) {
				Files.createFile(dest_input_file);
			}
			if(!Files.exists(dest_output_file)) {
				Files.createFile(dest_output_file);
			}*/
			
			//Transfer input file to destination folder
			input.transferTo(dest_input_file.toFile());
			
			//Transfer output file to destination folder
			output.transferTo(dest_output_file.toFile());
			
			//Update the property file with the location of the testdata uploaded
			updatePropertyFile(dest_input_file,Paths.get(destPath),testData);
			
			testData.setTcdInput(dest_input_file.toString());
			testData.setTcdExepOutput(dest_output_file.toString());
			
			if(testDataRepo.save(testData)!=null) {
				return true;
			}
		}
		return false;
	}

	private void updatePropertyFile(Path filePath , Path basePath, TestData testData) throws Exception {
		
		Path propPath = basePath.resolve(ITFConstants.RESOURCE_DIRNAME+testData.getTestSuite().getConfigFileName());
		
		PropertiesConfiguration dynamicProperties = new PropertiesConfiguration(propPath.toString());
		
		dynamicProperties.setProperty(ITFConstants.PAYLOAD_PATH, filePath.toString());
		dynamicProperties.save();
		
	}

	/* (non-Javadoc)
	 * @see com.ustglobal.itfportal.services.TestDataService#updateTestData(com.ustglobal.itfportal.entities.TestData)
	 */
	@Override
	public Boolean updateTestData(TestData testData) {
		if(testDataRepo.save(testData)!=null) {
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see com.ustglobal.itfportal.services.TestDataService#getTestCasesFromProperty()
	 */
	@Override
	public List<TestData> getTestCasesFromProperty() {
		// TODO Auto-generated method stub
		return gp.getTestcases();
	}

	/* (non-Javadoc)
	 * @see com.ustglobal.itfportal.services.TestDataService#getTestCasesDataFromDB()
	 */
	@Override
	public List<TestData> getTestCasesDataFromDB() {
		List<TestData> testDataList = new ArrayList<TestData>();
		testDataRepo.findAll().forEach(testDataList::add);
		return testDataList;
	}

}
