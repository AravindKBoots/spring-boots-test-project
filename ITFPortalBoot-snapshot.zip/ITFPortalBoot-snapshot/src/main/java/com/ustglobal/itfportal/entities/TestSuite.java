/**
 * 
 */
package com.ustglobal.itfportal.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author aravindk
 *
 */
@Entity
@Table(name = "test_suite", schema = "itfportal")
public class TestSuite {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long tsId;
	@Column(nullable = false)
	private String tsName;
	@Column(nullable = false)
	private String tsPlatform;
	@Column(nullable = false)
	private String inQ;
	@Column(nullable = false)
	private String outQ;
	private Boolean isExec = false;

	
	@Temporal(TemporalType.DATE)
	private Date lastUpdated;
	
	@Lob
	private Byte[] testResult;
	
	private String configFileName;
	
	@OneToOne
	@JoinColumn(name = "intfId", nullable = false)
	private InterfaceMaster interfaceMaster;
	
	
	public TestSuite() {
		
	}
	/**
	 * @return the tsPlatform
	 */
	public String getTsPlatform() {
		return tsPlatform;
	}
	/**
	 * @param tsQ the tsQ to set
	 */
	public void setTsPlatform(String tsPlatform) {
		this.tsPlatform = tsPlatform;
	}
	public String getTsName() {
		return tsName;
	}
	public void setTsName(String tsName) {
		this.tsName = tsName;
	}
	//private String inQwmb;
	/**
	 * @return the tsId
	 */
	public Long getTsId() {
		return tsId;
	}
	/**
	 * @return the inQ
	 */
	public String getInQ() {
		return inQ;
	}
	/**
	 * @param inQ the inQ to set
	 */
	public void setInQ(String inQ) {
		this.inQ = inQ;
	}
	/**
	 * @return the outQ
	 */
	public String getOutQ() {
		return outQ;
	}
	/**
	 * @param outQ the outQ to set
	 */
	public void setOutQ(String outQ) {
		this.outQ = outQ;
	}
	/**
	 * @return the isExec
	 */
	public Boolean getIsExec() {
		return isExec;
	}
	/**
	 * @return the lastUpdated
	 */
	public Date getLastUpdated() {
		return lastUpdated;
	}
	/**
	 * @return the testResultWmb
	 */
	public Byte[] getTestResult() {
		return testResult;
	}
	/**
	 * @return the interfaceMaster
	 */
	public InterfaceMaster getInterfaceMaster() {
		return interfaceMaster;
	}
	/**
	 * @param interfaceMaster the interfaceMaster to set
	 */
	public void setInterfaceMaster(InterfaceMaster interfaceMaster) {
		this.interfaceMaster = interfaceMaster;
	}
	/**
	 * @param tsId the tsId to set
	 */
	public void setTsId(Long tsId) {
		this.tsId = tsId;
	}
	/**
	 * @param isExec the isExec to set
	 */
	public void setIsExec(Boolean isExec) {
		this.isExec = isExec;
	}
	/**
	 * @param lastUpdated the lastUpdated to set
	 */
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	/**
	 * @param testResultWmb the testResultWmb to set
	 */
	public void setTestResult(Byte[] testResult) {
		this.testResult = testResult;
	}
	/**
	 * @return the configFileName
	 */
	public String getConfigFileName() {
		return configFileName;
	}
	/**
	 * @param configFileName the configFileName to set
	 */
	public void setConfigFileName(String configFileName) {
		this.configFileName = configFileName;
	}

}
