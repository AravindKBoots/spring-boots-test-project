/**
 * 
 */
package com.ustglobal.itfportal.controllers;

import java.io.FileInputStream;
import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ustglobal.itfportal.entities.TestExecution;
import com.ustglobal.itfportal.services.TestExecutionService;

/**
 * @author U42998
 *
 */
@RestController
public class TestExecutionController {
	
	@Autowired
	TestExecutionService testExecService;
	
	@GetMapping("/files/{id}")
	public ResponseEntity<Resource> downloadFile(@PathVariable("id") Long id) throws Exception {
		Path download_path =  testExecService.downloadTestResult(id);
		if(null != download_path) {
			InputStreamResource resource = new InputStreamResource(new FileInputStream(download_path.toFile()));
			 
	        return ResponseEntity.ok()
	                // Content-Disposition
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + download_path.getFileName())
	                // Content-Type
	                .contentType(MediaType.APPLICATION_OCTET_STREAM)
	                // Contet-Length
	                .contentLength(download_path.toFile().length()) 
	                .body(resource);
		}	
		return null;
	}
	
	@PostMapping("/testcases/execute")
	public Boolean executeTestCase(@RequestBody TestExecution testExecution) throws Exception {
		return testExecService.saveTestSuiteExecution(testExecution);
	}
	
	
	

}
