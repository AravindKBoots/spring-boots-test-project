/**
 * 
 */
package com.ustglobal.itfportal.constants;

/**
 * @author U42998
 *
 */
public enum ExecutionStatus {
	
	SUCCESS,FAILED,NOTEXECUTED,PENDING

}
