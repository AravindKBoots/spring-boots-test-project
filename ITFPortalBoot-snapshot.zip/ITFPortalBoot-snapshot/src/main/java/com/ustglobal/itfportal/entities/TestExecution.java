/**
 * 
 */
package com.ustglobal.itfportal.entities;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ustglobal.itfportal.constants.ExecutionStatus;

/**
 * @author U42998
 *
 */
@Entity
@Table(name = "test_execution", schema = "itfportal")
public class TestExecution {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long teId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date teDate;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private ExecutionStatus execStatus = ExecutionStatus.NOTEXECUTED;
	
	@OneToOne
	@JoinColumn(name = "tsId" , nullable = false)
	private TestSuite testSuite;

	/**
	 * @return the teId
	 */
	public Long getTeId() {
		return teId;
	}

	/**
	 * @return the teDate
	 */
	public Date getTeDate() {
		return teDate;
	}

	/**
	 * @return the testSuite
	 */
	public TestSuite getTestSuite() {
		return testSuite;
	}

	/**
	 * @param teId the teId to set
	 */
	public void setTeId(Long teId) {
		this.teId = teId;
	}

	/**
	 * @param teDate the teDate to set
	 */
	public void setTeDate(Date teDate) {
		this.teDate = teDate;
	}

	/**
	 * @return the execStatus
	 */
	public ExecutionStatus getExecStatus() {
		return execStatus;
	}

	/**
	 * @param execStatus the execStatus to set
	 */
	public void setExecStatus(ExecutionStatus execStatus) {
		this.execStatus = execStatus;
	}


	/**
	 * @param testSuite the testSuite to set
	 */
	public void setTestSuite(TestSuite testSuite) {
		this.testSuite = testSuite;
	}
}
