/**
 * 
 */
package com.ustglobal.itfportal.services;

import java.util.List;

import com.ustglobal.itfportal.entities.TestSuite;

/**
 * @author aravindk
 *
 */
public interface TestSuiteService {
	
	public Boolean saveTestSuite(TestSuite testSuite) throws Exception;
	public List<TestSuite> getAllTestSuites();

}
