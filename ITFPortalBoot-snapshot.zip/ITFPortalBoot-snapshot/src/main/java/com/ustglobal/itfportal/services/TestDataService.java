/**
 * 
 */
package com.ustglobal.itfportal.services;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ustglobal.itfportal.entities.TestData;

/**
 * @author U42998
 *
 */

public interface TestDataService {
	
	public Boolean createTestData(TestData testData, MultipartFile input, MultipartFile output) throws Exception;
	public Boolean updateTestData(TestData testData);
	public List<TestData> getTestCasesFromProperty();
	public List<TestData> getTestCasesDataFromDB();
}
