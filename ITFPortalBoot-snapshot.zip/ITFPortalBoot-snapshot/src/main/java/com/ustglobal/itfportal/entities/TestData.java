/**
 * 
 */
package com.ustglobal.itfportal.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author U42998
 *
 */
@Entity
@Table(name = "test_data", schema = "itfportal")
public class TestData {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long tcdId;
	private String tcName;
	private String tcdInput;
	private String tcdExepOutput;
	
	@OneToOne
	@JoinColumn(name = "tsId" , nullable = false)
	private TestSuite testSuite;
	
	/**
	 * @return the tcdId
	 */
	public Long getTcdId() {
		return tcdId;
	}
	/**
	 * @param tcdId the tcdId to set
	 */
	public void setTcdId(Long tcdId) {
		this.tcdId = tcdId;
	}
	/**
	 * @return the tcName
	 */
	public String getTcName() {
		return tcName;
	}
	/**
	 * @param tcName the tcName to set
	 */
	public void setTcName(String tcName) {
		this.tcName = tcName;
	}
	/**
	 * @return the tcdInput
	 */
	public String getTcdInput() {
		return tcdInput;
	}
	/**
	 * @param tcdInput the tcdInput to set
	 */
	public void setTcdInput(String tcdInput) {
		this.tcdInput = tcdInput;
	}
	/**
	 * @return the tcdExepOutput
	 */
	public String getTcdExepOutput() {
		return tcdExepOutput;
	}
	/**
	 * @param tcdExepOutput the tcdExepOutput to set
	 */
	public void setTcdExepOutput(String tcdExepOutput) {
		this.tcdExepOutput = tcdExepOutput;
	}
	/**
	 * @return the testSuite
	 */
	public TestSuite getTestSuite() {
		return testSuite;
	}
	/**
	 * @param testSuite the testSuite to set
	 */
	public void setTestSuite(TestSuite testSuite) {
		this.testSuite = testSuite;
	}
	
	
}
