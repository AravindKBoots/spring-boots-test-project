/**
 * 
 */
package com.ustglobal.itfportal.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ustglobal.itfportal.entities.InterfaceMaster;
import com.ustglobal.itfportal.entities.TestSuite;
import com.ustglobal.itfportal.services.InterfaceService;
import com.ustglobal.itfportal.services.TestSuiteService;

/**
 * @author U42998
 *
 */
@RestController
public class TestSuiteController {
	
	@Autowired
	InterfaceService intService;
	
	@Autowired
	TestSuiteService testSuiteService;

	@GetMapping("/interfaces")
	public List<InterfaceMaster> getAllInterfaces() {
		List<InterfaceMaster> interfaceList = new ArrayList<InterfaceMaster>();
		//System.out.println("List Properties"+ groovyProperties.getBatFileName());
		interfaceList = intService.getAllInterface();
		
		return interfaceList; 
	}
	
	@PostMapping("/interfaces")
	public void saveInterfaceMaster(@RequestBody InterfaceMaster intfMaster) {
		intService.saveInterface(intfMaster);
	}

	@PostMapping("/testsuites")
	public Boolean createTestcase(@RequestBody TestSuite testSuite) throws Exception{
		return testSuiteService.saveTestSuite(testSuite);
	}
	
	@GetMapping("/testsuites")
	public List<TestSuite> getAllTestSuites(){
		
		return testSuiteService.getAllTestSuites();
	}

}
