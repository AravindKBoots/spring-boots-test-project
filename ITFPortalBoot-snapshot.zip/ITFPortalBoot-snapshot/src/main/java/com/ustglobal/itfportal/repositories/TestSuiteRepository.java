/**
 * 
 */
package com.ustglobal.itfportal.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ustglobal.itfportal.entities.TestSuite;

/**
 * @author aravindk
 *
 */
@Repository
public interface TestSuiteRepository extends CrudRepository<TestSuite, Long> {

}
