/**
 * 
 */
package com.ustglobal.itfportal.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ustglobal.itfportal.entities.TestData;
import com.ustglobal.itfportal.services.TestDataService;

/**
 * @author aravindk
 *
 */
@RestController
public class TestDataController {
	
	@Autowired
	TestDataService testDataService;
	
	@GetMapping("/testcases/testdata")
	public List<TestData> getAllTestcaseWithTestData(){
			
		return testDataService.getTestCasesFromProperty();
	}
	
	
	/* All test cases are listed from property files */
	@GetMapping("/testcases/all")
	public List<TestData> getAllTestcase(){
			
		return testDataService.getTestCasesDataFromDB();
	}
	
	@PostMapping(value = "/testcases", consumes = "multipart/form-data")
	public Boolean createTestData(@RequestPart("testData") TestData testData,@RequestPart("input") MultipartFile input, 
					@RequestPart("output") MultipartFile output) throws Exception {
		
		return testDataService.createTestData(testData,input,output);
	}
	
	@PutMapping("/testcases")
	public Boolean updateTestData(@RequestBody TestData testData) {
		return testDataService.updateTestData(testData);
	}
}
