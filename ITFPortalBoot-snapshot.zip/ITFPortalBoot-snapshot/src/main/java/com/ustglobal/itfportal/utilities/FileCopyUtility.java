/**
 * 
 */
package com.ustglobal.itfportal.utilities;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;

import org.springframework.stereotype.Service;

/**
 * @author U42998
 *
 */
@Service

public class FileCopyUtility extends SimpleFileVisitor<Path>{
	

	private Path toPath;
	private Path fromPath;
	private Path fromFilePath;
	
	private StandardCopyOption scop = StandardCopyOption.REPLACE_EXISTING;

	@Override
	public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes arg1) throws IOException {
		Path copyPath = toPath.resolve(fromPath.relativize(dir));
		if(!Files.exists(copyPath)) {
			Files.createDirectory(copyPath);
		}
		return FileVisitResult.CONTINUE;
	}

	@Override
	public FileVisitResult visitFile(Path file, BasicFileAttributes arg1) throws IOException {
		Path copyPath = toPath.resolve(fromPath.relativize(file));
		if((fromFilePath == null) || (fromFilePath != null && fromFilePath.equals(file))) {
			/*Can be considered in future for performance if needed.
			 * if(Files.exists(copyPath)) {
				return FileVisitResult.CONTINUE;
			}*/
			Files.copy(file, copyPath ,scop);
		}
		return FileVisitResult.CONTINUE;
	}
	@Override
	public FileVisitResult visitFileFailed(Path arg0, IOException arg1) throws IOException {
		// TODO Auto-generated method stub
		return FileVisitResult.SKIP_SUBTREE;
	}

	/**
	 * @return the toPath
	 */
	public Path getToPath() {
		return toPath;
	}

	/**
	 * @param toPath the toPath to set
	 */
	public void setToPath(Path toPath) {
		this.toPath = toPath;
	}


	/**
	 * @param fromPath the fromPath to set
	 */
	public void setFromPath(Path fromPath) {
		this.fromPath = fromPath;
	}

	/**
	 * @param fromFilePath the fromFilePath to set
	 */
	public void setFromFilePath(Path fromFilePath) {
		this.fromFilePath = fromFilePath;
	}
		
}
