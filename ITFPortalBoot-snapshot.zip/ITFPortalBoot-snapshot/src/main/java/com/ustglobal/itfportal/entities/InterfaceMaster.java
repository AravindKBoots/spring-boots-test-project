/**
 * 
 */
package com.ustglobal.itfportal.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author aravindk
 *
 */
@Entity
@Table(name = "interface_master", schema = "itfportal")
public class InterfaceMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long intfId;
	private String intfName;
	private String intgPat;

	public InterfaceMaster() {
		
	}

/*	public TestSuite getTestSuite() {
		return testSuite;
	}

	public void setTestSuite(TestSuite testSuite) {
		this.testSuite = testSuite;
	}*/

	public InterfaceMaster(Long intfId, String intfName, String intgPat) {
		this.intfId = intfId;
		this.intfName = intfName;
		this.intgPat = intgPat;
	}

	public Long getIntfId() {
		return intfId;
	}

	public String getIntfName() {
		return intfName;
	}

	public String getIntgPat() {
		return intgPat;
	}

	public void setIntfId(Long intfId) {
		this.intfId = intfId;
	}

	public void setIntfName(String intfName) {
		this.intfName = intfName;
	}

	public void setIntgPat(String intgPat) {
		this.intgPat = intgPat;
	}

}
