/**
 * 
 */
package com.ustglobal.itfportal.services.impl;

import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.zip.ZipOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;

import com.ustglobal.itfportal.configs.GroovyProperties;
import com.ustglobal.itfportal.constants.ExecutionStatus;
import com.ustglobal.itfportal.constants.ITFConstants;
import com.ustglobal.itfportal.entities.TestExecution;
import com.ustglobal.itfportal.entities.TestSuite;
import com.ustglobal.itfportal.repositories.TestExecutionRepository;
import com.ustglobal.itfportal.repositories.TestSuiteRepository;
import com.ustglobal.itfportal.services.TestExecutionService;
import com.ustglobal.itfportal.utilities.FileZipUtility;

/**
 * @author U42998
 *
 */
@Service
@EnableConfigurationProperties(GroovyProperties.class)
public class TestExecutionServiceImpl implements TestExecutionService {
	
	@Autowired
	TestExecutionRepository testExecRepo;
	
	@Autowired
	TestSuiteRepository testSuiteRepo;
	
	@Autowired
	GroovyProperties gp;
	
	@Autowired
	FileZipUtility fzp;

	@Override
	public Boolean saveTestSuiteExecution(TestExecution testExecution) throws Exception {
		
		Integer status = executeGradleCommands(testExecution);
		testExecution.setExecStatus(status == 0?ExecutionStatus.SUCCESS:ExecutionStatus.FAILED);
		testExecution.getTestSuite().setIsExec(Boolean.TRUE);
		testExecution.setTeDate(Calendar.getInstance().getTime());
		
		if(testExecRepo.save(testExecution)!=null 
				&& testSuiteRepo.save(testExecution.getTestSuite())!= null && status == 0) {
			return true;
		}
		return false;
	}
	
	private Integer executeGradleCommands(TestExecution testExecution) throws Exception {
		
		Path working_dir_path = Paths.get(gp.getTestCaseCreationPath()+testExecution.getTestSuite().getTsName());
		
		Path execution_log_path = working_dir_path.resolve(gp.getGradleLogName());
		
		Files.deleteIfExists(execution_log_path);
		Files.createFile(execution_log_path);
		
		ProcessBuilder gradleBuilder = new ProcessBuilder(gp.getGradleCommands());
		
		gradleBuilder.directory(working_dir_path.toFile());
		
		gradleBuilder.redirectErrorStream(true);
		
		gradleBuilder.redirectOutput(execution_log_path.toFile());
		
		Process p = gradleBuilder.start();
		
		Integer status = p.waitFor();
		
		return status;
	}

	@Override
	public Path downloadTestResult(Long id) throws Exception {
		
		//get the testsuite using id
		TestSuite testSuite = testSuiteRepo.findOne(id);
		
		//Zipping the results dir
		Path working_dir_path = Paths.get(gp.getTestCaseCreationPath()+testSuite.getTsName());
		Path source_path = working_dir_path.resolve(ITFConstants.TESTRESULT_DIR);
		if(Files.exists(source_path)) {
			Path zip_path = working_dir_path.resolve(gp.getZipFileName());
			ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip_path.toFile()));
			fzp.setSourcePath(source_path);
			fzp.setZos(zos);
			
			Files.walkFileTree(source_path, fzp);
			zos.close();
			return zip_path;
		}
		return null;
	}

}
