/**
 * 
 */
package com.ustglobal.itfportal.configs;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

import com.ustglobal.itfportal.entities.TestData;

/**
 * @author aravindk
 *
 */
@ConfigurationProperties(prefix="test")
public class GroovyProperties {
	
	private String filepath;
	private String testCaseCreationPath;
	private String WMBQM;
	private String SAGUM;
	private String zipFileName;
	private String gradleLogName;
	private String configFileName;
	private String templateGradleFolder;
	private String templateJavaFolder;
	private String templateConfigFolder;
	private String templateTestcaseFolder;
	private String externalLibFolder;
	private List<TestData> testcases;
	private List<String> gradleCommands;
	private String umUrl;
	/**
	 * @return the filepath
	 */
	public String getFilepath() {
		return filepath;
	}
	/**
	 * @return the testCaseCreationPath
	 */
	public String getTestCaseCreationPath() {
		return testCaseCreationPath;
	}
	/**
	 * @return the wMBQM
	 */
	public String getWMBQM() {
		return WMBQM;
	}
	/**
	 * @return the sAGUM
	 */
	public String getSAGUM() {
		return SAGUM;
	}
	/**
	 * @return the itfRootDir
	 */
	public String getZipFileName() {
		return zipFileName;
	}
	/**
	 * @return the batFileName
	 */
	public String getGradleLogName() {
		return gradleLogName;
	}
	/**
	 * @return the configFileName
	 */
	public String getConfigFileName() {
		return configFileName;
	}
	/**
	 * @return the templateGradleFolder
	 */
	public String getTemplateGradleFolder() {
		return templateGradleFolder;
	}
	/**
	 * @return the templateJavaFolder
	 */
	public String getTemplateJavaFolder() {
		return templateJavaFolder;
	}
	/**
	 * @return the templateConfigFolder
	 */
	public String getTemplateConfigFolder() {
		return templateConfigFolder;
	}
	/**
	 * @return the templateTestcaseFolder
	 */
	public String getTemplateTestcaseFolder() {
		return templateTestcaseFolder;
	}
	/**
	 * @return the externalLibFolder
	 */
	public String getExternalLibFolder() {
		return externalLibFolder;
	}
	/**
	 * @return the testcases
	 */
	public List<TestData> getTestcases() {
		return testcases;
	}
	/**
	 * @return the gradleCommands
	 */
	public List<String> getGradleCommands() {
		return gradleCommands;
	}
	/**
	 * @param filepath the filepath to set
	 */
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	/**
	 * @param testCaseCreationPath the testCaseCreationPath to set
	 */
	public void setTestCaseCreationPath(String testCaseCreationPath) {
		this.testCaseCreationPath = testCaseCreationPath;
	}
	/**
	 * @param wMBQM the wMBQM to set
	 */
	public void setWMBQM(String wMBQM) {
		WMBQM = wMBQM;
	}
	/**
	 * @param sAGUM the sAGUM to set
	 */
	public void setSAGUM(String sAGUM) {
		SAGUM = sAGUM;
	}
	/**
	 * @param itfRootDir the itfRootDir to set
	 */
	public void setZipFileName(String zipFileName) {
		this.zipFileName = zipFileName;
	}
	/**
	 * @param gradleLogName the gradleLogName to set
	 */
	public void setGradleLogName(String gradleLogName) {
		this.gradleLogName = gradleLogName;
	}
	/**
	 * @param configFileName the configFileName to set
	 */
	public void setConfigFileName(String configFileName) {
		this.configFileName = configFileName;
	}
	/**
	 * @param templateGradleFolder the templateGradleFolder to set
	 */
	public void setTemplateGradleFolder(String templateGradleFolder) {
		this.templateGradleFolder = templateGradleFolder;
	}
	/**
	 * @param templateJavaFolder the templateJavaFolder to set
	 */
	public void setTemplateJavaFolder(String templateJavaFolder) {
		this.templateJavaFolder = templateJavaFolder;
	}
	/**
	 * @param templateConfigFolder the templateConfigFolder to set
	 */
	public void setTemplateConfigFolder(String templateConfigFolder) {
		this.templateConfigFolder = templateConfigFolder;
	}
	/**
	 * @param templateTestcaseFolder the templateTestcaseFolder to set
	 */
	public void setTemplateTestcaseFolder(String templateTestcaseFolder) {
		this.templateTestcaseFolder = templateTestcaseFolder;
	}
	/**
	 * @param externalLibFolder the externalLibFolder to set
	 */
	public void setExternalLibFolder(String externalLibFolder) {
		this.externalLibFolder = externalLibFolder;
	}
	/**
	 * @param testcases the testcases to set
	 */
	public void setTestcases(List<TestData> testcases) {
		this.testcases = testcases;
	}
	/**
	 * @param gradleCommands the gradleCommands to set
	 */
	public void setGradleCommands(List<String> gradleCommands) {
		this.gradleCommands = gradleCommands;
	}
	/**
	 * @return the umUrl
	 */
	public String getUmUrl() {
		return umUrl;
	}
	/**
	 * @param umUrl the umUrl to set
	 */
	public void setUmUrl(String umUrl) {
		this.umUrl = umUrl;
	}


	

}
