/**
 * 
 */
package com.ustglobal.itfportal.utilities;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.stereotype.Service;

/**
 * @author U42998
 *
 */
@Service
public class FileZipUtility extends SimpleFileVisitor<Path>{

	private ZipOutputStream zos;
	
	private Path sourcePath;
		
	@Override
	public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
		
		Path fileToZip = sourcePath.relativize(file);
		zos.putNextEntry(new ZipEntry(fileToZip.toString()));
		byte[] b = Files.readAllBytes(file);
		zos.write(b, 0, b.length);
		zos.closeEntry();
		
		return FileVisitResult.CONTINUE;
	}

	/**
	 * @param zos the zos to set
	 */
	public void setZos(ZipOutputStream zos) {
		this.zos = zos;
	}

	/**
	 * @param sourcePath the sourcePath to set
	 */
	public void setSourcePath(Path sourcePath) {
		this.sourcePath = sourcePath;
	}

	
	

}
