/**
 * 
 */
package com.ustglobal.itfportal.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author U42998
 *
 */
@Controller
public class HomeController {
	
	@GetMapping("/")
	public String homeRouting() {
		return "index.html";
	}
	
	@GetMapping("/ui/*")
	public String angularRouting() {
		return "redirect:/";
	}

}
