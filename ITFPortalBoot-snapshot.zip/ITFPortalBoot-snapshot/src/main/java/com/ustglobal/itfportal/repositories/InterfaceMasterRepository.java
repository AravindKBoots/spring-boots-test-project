/**
 * 
 */
package com.ustglobal.itfportal.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ustglobal.itfportal.entities.InterfaceMaster;

/**
 * @author aravindk
 *
 */
public interface InterfaceMasterRepository extends CrudRepository<InterfaceMaster, Long> {

}
