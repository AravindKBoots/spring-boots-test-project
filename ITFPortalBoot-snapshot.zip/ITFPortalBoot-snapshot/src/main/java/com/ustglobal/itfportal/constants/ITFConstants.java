package com.ustglobal.itfportal.constants;

public class ITFConstants {
	
	


	public static String EXTERNALLIB_FOLDER = "ExternalLibs";
	public static String CONFIG_DIRNAME="/configs";
	public static String JAVA_BASE_PACKAGE="/org/ust/itf";
	public static String SRC_DIRNAME="/src/test/groovy";
	public static String RESOURCE_DIRNAME="src/test/resources/";
	public static String TSNAME_SEPERATOR = "$";
	public static String TESTRESULT_DIR = "build/reports/tests/";
	public static String UM_URL = "umUrl";
/*	public static String TEMPLATE_FILE_NAME = "template";
	public static String JAVA_EXT = ".java";*/
	//public static String UM_ASYNC_TEST="org.ust.itf.UmAsyncReqReply";
	//public static String DYNAMIC_GROOVY_DIRNAME="/org/ust/itf";
	public static String LABEL_FOR_TSPROPS="Testsuite Properties";
	public static String LABEL_FOR_TDPROPS="TestData Properties";
	public static String LABEL_SYNC="Sync";
	public static String LABEL_ASYNC="Async";
	//public static String CONFIG_DIR_PATH="\\configs";
	public static String WMQ_CONFIG_FILE_NAME="wmq.properties";
	public static String UM_CONFIG_FILE_NAME="umq.properties";
	public static String KEY_QM ="QM";
	public static String UM_ASYNC_REQ_Q="umAsyncRequestQ";
	public static String UM_ASYNC_RES_Q="umAsyncReplyQ";
	public static String PAYLOAD_PATH="payloadPath";
	public static String UM_SYNC_REQ_Q="umSyncRequestQ";
	public static String UM_SYNC_RES_Q="umSyncReplyQ";
	public static String UM_SYNC_PAYLOAD_PATH="umSyncPayloadPath";
	public static String MQ_ASYNC_REQ_Q="wmAsyncRequestQ";
	public static String MQ_ASYNC_RES_Q="wmAsyncReplyQ";
	public static String MQ_ASYNC_PAYLOAD_PATH="wmAsyncPayloadPath";
	public static String MQ_SYNC_REQ_Q="wmSyncRequestQ";
	public static String MQ_SYNC_RES_Q="wmSyncReplyQ";
	public static String MQ_SYNC_PAYLOAD_PATH="wmSyncPayloadPath";
	public static String EMPTY_STRING="";
}
