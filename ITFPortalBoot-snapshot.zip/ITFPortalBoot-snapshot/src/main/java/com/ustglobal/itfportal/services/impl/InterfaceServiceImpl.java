/**
 * 
 */
package com.ustglobal.itfportal.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ustglobal.itfportal.entities.InterfaceMaster;
import com.ustglobal.itfportal.repositories.InterfaceMasterRepository;
import com.ustglobal.itfportal.services.InterfaceService;

/**
 * @author aravindk
 *
 */
@Service
public class InterfaceServiceImpl implements InterfaceService {

	@Autowired
	InterfaceMasterRepository interfaceRepo;

	@Override
	public Boolean saveInterface(InterfaceMaster interfaceMaster) {
		if(interfaceRepo.save(interfaceMaster)!=null) {
			return true;
		}
		return false;
	}

	@Override
	public List<InterfaceMaster> getAllInterface() {
		List<InterfaceMaster> intMasterList = new ArrayList<InterfaceMaster>();
		interfaceRepo.findAll().forEach(intMasterList::add);
		return intMasterList;
	}

}
