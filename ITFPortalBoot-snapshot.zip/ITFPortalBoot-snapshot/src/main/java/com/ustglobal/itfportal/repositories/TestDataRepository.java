/**
 * 
 */
package com.ustglobal.itfportal.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ustglobal.itfportal.entities.TestData;

/**
 * @author U42998
 *
 */
@Repository
public interface TestDataRepository extends CrudRepository<TestData, Long>{

}
