/**
 * 
 */
package com.ustglobal.itfportal.services.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.ustglobal.itfportal.configs.GroovyProperties;
import com.ustglobal.itfportal.constants.ITFConstants;
import com.ustglobal.itfportal.entities.TestSuite;
import com.ustglobal.itfportal.repositories.TestSuiteRepository;
import com.ustglobal.itfportal.services.TestSuiteService;
import com.ustglobal.itfportal.utilities.FileCopyUtility;

/**
 * @author aravindk
 *
 */

@Service
@EnableConfigurationProperties(GroovyProperties.class)
public class TestSuiteServiceImpl implements TestSuiteService{

	@Autowired
	private TestSuiteRepository testSuiteRepo;
	
	@Autowired
	private GroovyProperties gp;
	
	@Autowired
	private FileCopyUtility fcp;
	
	@Override
	public Boolean saveTestSuite(TestSuite testSuite) throws Exception{
		testSuite.setLastUpdated(new Date());
		if(createGradleSpockStructure(testSuite) && testSuiteRepo.save(testSuite)!=null) {
			return true;
		}
		return false;
	}
	
	@Override
	public List<TestSuite> getAllTestSuites() {
		List<TestSuite> testSuiteList = new ArrayList<TestSuite>();
		testSuiteRepo.findAll().forEach(testSuiteList::add);
		return testSuiteList;
	}
	
	private Boolean createGradleSpockStructure(TestSuite testSuite) throws IOException{
		
		Properties dynamicProperties = new Properties();
		FileWriter writer = null;
		String sourceGroovy = ITFConstants.EMPTY_STRING;
		String QMName = ITFConstants.EMPTY_STRING;
		String sourceConfig = ITFConstants.EMPTY_STRING;
		boolean testCaseCreatedFlag = Boolean.TRUE;
		String propReqKey = ITFConstants.EMPTY_STRING;
		String propResKey = ITFConstants.EMPTY_STRING;

		String integrationPattern = testSuite.getInterfaceMaster().getIntgPat();
		testSuite.setTsName(testSuite.getTsName()+ITFConstants.TSNAME_SEPERATOR+System.currentTimeMillis());
		String testSuiteNameFolder = testSuite.getTsName()+File.separator;
		String groovyLoc = testSuiteNameFolder + ITFConstants.SRC_DIRNAME + ITFConstants.JAVA_BASE_PACKAGE;
		String configLoc = groovyLoc + ITFConstants.CONFIG_DIRNAME;
		String configFileName = ITFConstants.EMPTY_STRING;
		switch (testSuite.getTsPlatform()) {
		case "WMB":
			QMName = gp.getWMBQM();
			if (integrationPattern.trim().startsWith(ITFConstants.LABEL_SYNC)) {
				sourceGroovy = "WmqSyncReqReply.groovy";
				propReqKey = ITFConstants.MQ_SYNC_REQ_Q;
				propResKey = ITFConstants.MQ_SYNC_RES_Q;
	
			} else if (integrationPattern.trim().startsWith(ITFConstants.LABEL_ASYNC)) {
				sourceGroovy = "WmqAsyncReqReply.groovy";
				propReqKey = ITFConstants.MQ_ASYNC_REQ_Q;
				propResKey = ITFConstants.MQ_ASYNC_RES_Q;
			}
			sourceConfig = "WmqConfig.java";
			configFileName = ITFConstants.WMQ_CONFIG_FILE_NAME;
			break;
		case "SAG":
			QMName = gp.getSAGUM();
			dynamicProperties.setProperty(ITFConstants.UM_URL,gp.getUmUrl());
			if (integrationPattern.trim().startsWith(ITFConstants.LABEL_SYNC)) {
				sourceGroovy = "UmSyncReqReply.groovy";
				propReqKey = ITFConstants.UM_SYNC_REQ_Q;
				propResKey = ITFConstants.UM_SYNC_RES_Q;
			} else if (integrationPattern.trim().startsWith(ITFConstants.LABEL_ASYNC)) {
				sourceGroovy = "UmAsyncReqReply.groovy";
				propReqKey = ITFConstants.UM_ASYNC_REQ_Q;
				propResKey = ITFConstants.UM_ASYNC_RES_Q;
			}
			sourceConfig = "UmqConfig.java";
			configFileName = ITFConstants.UM_CONFIG_FILE_NAME;
			break;
		}
		if (!sourceGroovy.equals("")) {
			testSuite.setConfigFileName(configFileName);
			//Copying External Libs to the root folder so that it can be commonly used
			
			copyFiles(gp.getExternalLibFolder(), ITFConstants.EXTERNALLIB_FOLDER, null);			
			
			//Copying Common gradle Files third argument specifies the filename to be filtered
			
			copyFiles(gp.getTemplateGradleFolder(), testSuiteNameFolder, null);
			
			//Copying Common Java Files
			
			copyFiles(gp.getTemplateJavaFolder(), groovyLoc, null);
			
			//Copying Groovy Testcases
			
			copyFiles(gp.getTemplateTestcaseFolder(), groovyLoc, sourceGroovy);
			
			//Copying Groovy java Configs
			
			copyFiles(gp.getTemplateConfigFolder(), configLoc, sourceConfig);
			
			//Creating .properties file
			
			Path dirPath = createDirectories(testSuiteNameFolder+ITFConstants.RESOURCE_DIRNAME);	
			if(!Files.exists(dirPath.resolve(Paths.get(configFileName)))) {
				Path propPath = Files.createFile(dirPath.resolve(Paths.get(configFileName)));
				writer = new FileWriter(propPath.toFile());
				dynamicProperties.setProperty(ITFConstants.KEY_QM, QMName);
				dynamicProperties.setProperty(propReqKey, testSuite.getInQ());
				dynamicProperties.setProperty(propResKey, testSuite.getOutQ());
				dynamicProperties.store(writer, ITFConstants.LABEL_FOR_TSPROPS);
				writer.close();
			}
		}

		return testCaseCreatedFlag;
	}
	
	private void copyFiles(String fromPath, String toPath, String fileName) throws IOException {
		
		Path destBasePath = Paths.get(gp.getTestCaseCreationPath());
		Path to_path = destBasePath.resolve(Paths.get(toPath));
		Path sourceBasePath = Paths.get(gp.getFilepath());
		Path from_path = sourceBasePath.resolve(Paths.get(fromPath));
		Path from_file_path = null;
		if(!StringUtils.isEmpty(fileName)) {
			from_file_path = from_path.resolve(Paths.get(fileName));
		}
		if(!Files.exists(to_path)) {
			Files.createDirectories(to_path);
		}
		fcp.setToPath(to_path);
		fcp.setFromPath(from_path);
		fcp.setFromFilePath(from_file_path);
		//calling fileCopy utility for copying the files
		Files.walkFileTree(from_path, fcp);
		
	}
	
	private Path createDirectories(String location) throws IOException {
		Path destBasePath = Paths.get(gp.getTestCaseCreationPath());
		Path destination = destBasePath.resolve(Paths.get(location));
		if(!Files.exists(destination)) {
			Files.createDirectories(destination);
		}
		return destination;
	}
	
}
			