/**
 * 
 */
package com.ustglobal.itfportal.services;

import java.util.List;

import com.ustglobal.itfportal.entities.InterfaceMaster;

/**
 * @author aravindk
 *
 */

public interface InterfaceService {

	public Boolean saveInterface(InterfaceMaster interfaceMaster);

	public List<InterfaceMaster> getAllInterface();

}
