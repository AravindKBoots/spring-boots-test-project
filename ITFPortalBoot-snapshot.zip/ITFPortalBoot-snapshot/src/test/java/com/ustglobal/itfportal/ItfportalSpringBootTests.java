/**
 * 
 */
package com.ustglobal.itfportal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author U42998
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class ItfportalSpringBootTests {

	/**
	 * @param args
	 */
	@Test
	public void testMethod() {
		
	}

}
